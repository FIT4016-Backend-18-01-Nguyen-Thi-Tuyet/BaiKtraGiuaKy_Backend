using Microsoft.EntityFrameworkCore;
using System;

namespace SchoolManagement
{
    public class SchoolDbContext : DbContext
    {
        public DbSet<School> Schools { get; set; }
        public DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Kiểm tra kỹ tên Server của bạn tại đây
            optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=SchoolManagement;Trusted_Connection=True;TrustServerCertificate=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // 1. Cấu hình các ràng buộc Unique (Duy nhất)
            modelBuilder.Entity<School>().HasIndex(s => s.Name).IsUnique();
            modelBuilder.Entity<Student>().HasIndex(s => s.StudentId).IsUnique();
            modelBuilder.Entity<Student>().HasIndex(s => s.Email).IsUnique();

            // Sử dụng một mốc thời gian cố định cho Seed Data
            DateTime seedDate = new DateTime(2024, 5, 20);

            // 2. Seed Data cho Schools (10 records)
            for (int i = 1; i <= 10; i++)
            {
                modelBuilder.Entity<School>().HasData(new School 
                { 
                    Id = i, 
                    Name = $"School {i}", 
                    Principal = $"Principal {i}", 
                    Address = $"{i} Education St",
                    CreatedAt = seedDate,
                    UpdatedAt = seedDate
                });
            }

            // 3. Seed Data for Students (20 records)
            for (int i = 1; i <= 20; i++)
            {
                modelBuilder.Entity<Student>().HasData(new Student 
                { 
                    Id = i, 
                    // (i % 10) + 1 đảm bảo SchoolId luôn nằm trong khoảng từ 1 đến 10
                    SchoolId = (i % 10) + 1, 
                    FullName = $"Student Name {i}", 
                    StudentId = $"STD{1000 + i}", 
                    Email = $"student{i}@example.com",
                    Phone = $"09012345{i:D2}",
                    CreatedAt = seedDate,
                    UpdatedAt = seedDate
                });
            }
        }
    }
}