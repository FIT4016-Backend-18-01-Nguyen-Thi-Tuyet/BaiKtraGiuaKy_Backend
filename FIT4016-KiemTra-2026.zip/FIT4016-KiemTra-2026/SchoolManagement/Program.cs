﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using SchoolManagement;

using (var db = new SchoolDbContext())
{
    // Ensure DB is created and seeded
    db.Database.EnsureCreated();

    while (true)
    {
        Console.WriteLine("\n--- STUDENT MANAGEMENT SYSTEM ---");
        Console.WriteLine("1. List Students (Pagination)");
        Console.WriteLine("2. Create Student");
        Console.WriteLine("3. Update Student");
        Console.WriteLine("4. Delete Student");
        Console.WriteLine("0. Exit");
        Console.Write("Select an option: ");

        var choice = Console.ReadLine();
        try
        {
            switch (choice)
            {
                case "1": ListStudents(db); break;
                case "2": CreateStudent(db); break;
                case "3": UpdateStudent(db); break;
                case "4": DeleteStudent(db); break;
                case "0": return;
                default: Console.WriteLine("Invalid choice!"); break;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERROR]: {ex.Message}");
        }
    }
}

// 2. Read - List Students with Pagination
static void ListStudents(SchoolDbContext db)
{
    Console.Write("Enter page number (10 students/page): ");
    if (!int.TryParse(Console.ReadLine(), out int page)) page = 1;

    var students = db.Students
        .Include(s => s.School)
        .OrderBy(s => s.Id)
        .Skip((page - 1) * 10)
        .Take(10)
        .ToList();

    Console.WriteLine("\n{0,-20} | {1,-15} | {2,-25} | {3,-12} | {4}", "Full Name", "Student ID", "Email", "Phone", "School");
    Console.WriteLine(new string('-', 90));

    foreach (var s in students)
    {
        Console.WriteLine("{0,-20} | {1,-15} | {2,-25} | {3,-12} | {4}", 
            s.FullName, s.StudentId, s.Email, s.Phone, s.School.Name);
    }
}

// 1. Create Student
static void CreateStudent(SchoolDbContext db)
{
    var s = new Student();
    Console.Write("Full Name: "); s.FullName = Console.ReadLine();
    Console.Write("Student ID: "); s.StudentId = Console.ReadLine();
    Console.Write("Email: "); s.Email = Console.ReadLine();
    Console.Write("Phone: "); s.Phone = Console.ReadLine();
    Console.Write("School ID: "); s.SchoolId = int.Parse(Console.ReadLine());

    // Validation
    var context = new ValidationContext(s);
    var results = new List<ValidationResult>();
    if (!Validator.TryValidateObject(s, context, results, true))
    {
        results.ForEach(r => Console.WriteLine($"- {r.ErrorMessage}"));
        return;
    }

    db.Students.Add(s);
    db.SaveChanges();
    Console.WriteLine("Student created successfully!");
}

// 3. Update Student
static void UpdateStudent(SchoolDbContext db)
{
    Console.Write("Enter Student ID to update: ");
    var sid = Console.ReadLine();
    var student = db.Students.FirstOrDefault(s => s.StudentId == sid);

    if (student == null) throw new Exception("Student not found.");

    Console.Write("New Full Name (leave blank to skip): ");
    var name = Console.ReadLine();
    if (!string.IsNullOrEmpty(name)) student.FullName = name;

    Console.Write("New Email: ");
    student.Email = Console.ReadLine();

    db.SaveChanges();
    Console.WriteLine("Student updated successfully!");
}

// 4. Delete Student
static void DeleteStudent(SchoolDbContext db)
{
    Console.Write("Enter Student ID to delete: ");
    var sid = Console.ReadLine();
    var student = db.Students.FirstOrDefault(s => s.StudentId == sid);

    if (student == null) throw new Exception("Student not found.");

    Console.Write($"Are you sure you want to delete {student.FullName}? (y/n): ");
    if (Console.ReadLine().ToLower() == "y")
    {
        db.Students.Remove(student);
        db.SaveChanges();
        Console.WriteLine("Student deleted.");
    }
}